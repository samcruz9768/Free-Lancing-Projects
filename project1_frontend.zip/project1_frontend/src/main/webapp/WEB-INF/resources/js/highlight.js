$(function(){
	
	switch(menu){
	case 'About':
		$('#about').addClass('active');
		break;
	case 'Home':
		$('#home').addClass('active');
		break;
	case 'Login':
		$('#login').addClass('active');
		break;
	case 'Cart':
		$('#cart').addClass('active');
		break;
	case 'Add Product':
		$('#productform').addClass('active');
		break;
	case 'Contact':
		$('#contact').addClass('active');
		break;
	case 'All Products':
		$('#allproduct').addClass('active');
		break;
	case 'Head Phones':
		$('#l_'+menu).addClass('active');
	case 'Mobiles':
		$('#l_'+menu).addClass('active');
	case 'Laptops':
		$('#l_'+menu).addClass('active');
	default:
		
		break;
	}
})